########################################
#Author : Sumit Paria for Informatica. #
#Date : 27-Feb-2019                    #
########################################
import json
import boto3
import cfnresponse
import sys
responseData = {}
def lambda_handler(event, context):
 if event['RequestType'] == 'Delete' :
  responseData['Data'] = 0,
  cfnresponse.send(event, context, cfnresponse.SUCCESS,responseData)
  sys.exit()
 vpcid = event['ResourceProperties']['VPCID']
 publicsubnetid = event['ResourceProperties']['PublicSubnetID']
 servicesubnetid1 = event['ResourceProperties']['ServiceSubnetID1']
 servicesubnetid2 = event['ResourceProperties']['ServiceSubnetID2']
 deployRDP = event['ResourceProperties']['DeployRemoteServer']
 region = event['ResourceProperties']['Region']
 
 if deployRDP in ["Yes"]:
  serviceSubnet1azResult = subnet_az_checker(servicesubnetid1, region)
  serviceSubnet2azResult = subnet_az_checker(servicesubnetid2, region)
  if serviceSubnet1azResult in serviceSubnet2azResult:
   responseData['Data'] = "Availability zone for two service subnets must not be same."
   cfnresponse.send(event, context, cfnresponse.FAILED,responseData,"SubnetCheckInfo")
  else:
   deployRDP_yes(event, context, vpcid, publicsubnetid, servicesubnetid1, region)
 else:
  serviceSubnet1azResult = subnet_az_checker(servicesubnetid1, region)
  serviceSubnet2azResult = subnet_az_checker(servicesubnetid2, region)
  if serviceSubnet1azResult in serviceSubnet2azResult:
   responseData['Data'] = "Availability zone for two service subnets must not be same."
   cfnresponse.send(event, context, cfnresponse.FAILED,responseData,"SubnetCheckInfo")
  else:
   deployRDP_no(event, context, vpcid, servicesubnetid1, region)

def subnet_checker(vpcId, subnetId, regionId, subnetType):
 vpcid = vpcId
 subnetid = subnetId
 region = regionId
 subnettype = subnetType
 continue_execution = "true"
 return_result = "false"
 ec2 = boto3.resource('ec2', region_name=region)
 client = boto3.client('ec2')
 vpc = ec2.Vpc(id=vpcid)
 routetables = vpc.route_tables.all()
 for routetable in routetables:
  route_table = ec2.RouteTable(routetable.id)
  routetable_association_attributes = route_table.associations_attribute
  if continue_execution in ["false"]:
   break
  for raa in routetable_association_attributes:
   raa_strng = str(raa)
   raa_strng = json.dumps(raa)
   raa_strng_json_obj = json.loads(raa_strng)
   if continue_execution in ["false"]:
     break
   if 'SubnetId' in raa_strng_json_obj:
     subnet_id = raa_strng_json_obj["SubnetId"]
     if subnet_id in [subnetid]:
       continue_execution = "false"
       routes_attributes = route_table.routes_attribute
       for ra in routes_attributes:
        ra_strng = str(ra)
        ra_strng = json.dumps(ra)
        gateway=""
        natgateway=""
        ra_strng_json_obj = json.loads(ra_strng)
        if "GatewayId" in ra_strng_json_obj:
         gateway = ra_strng_json_obj["GatewayId"]
        if "NatGatewayId" in ra_strng_json_obj:
         natgateway = ra_strng_json_obj["NatGatewayId"]
        state = ra_strng_json_obj["State"]
        if "igw-" in gateway:
         if subnettype in ["public"]:
          if state in ["active"]:
            return_result = "true"
        if "nat-" in natgateway:
          if subnettype in ["nat-iwg"]:
           if state in ["active"]:
             return_result = "true"
        if "igw-" in gateway:
         if subnettype in ["nat-iwg"]:
          if state in ["active"]:
            return_result = "true"
       break
 return return_result
 
def deployRDP_yes(event, context, vpcId, publicsubnetid, servicesubnetid1, regionId):
 publicSubnetResult = subnet_checker(vpcId, publicsubnetid, regionId, "public")
 serviceSubnet1Result = subnet_checker(vpcId, servicesubnetid1, regionId, "nat-iwg")
 if publicSubnetResult in ["true"]:
  if serviceSubnet1Result in ["true"]:
   responseData['Data'] = "All Subnets are OK verified."
   cfnresponse.send(event, context, cfnresponse.SUCCESS,responseData,"SubnetCheckInfo")
  else:
    responseData['Data'] = "Service Subnet1 is not attached to an Internet Gateway or NAT Gateway."
    cfnresponse.send(event, context, cfnresponse.FAILED,responseData,"SubnetCheckInfo")
 else:
  responseData['Data'] = "public subnet is not attached to an Internet Gateway."
  cfnresponse.send(event, context, cfnresponse.FAILED,responseData,"SubnetCheckInfo")

def deployRDP_no(event, context, vpcId, servicesubnetid1, regionId):
 serviceSubnet1Result = subnet_checker(vpcId, servicesubnetid1, regionId, "nat-iwg")
 if serviceSubnet1Result in ["true"]:
  responseData['Data'] = "All Subnets are OK verified."
  cfnresponse.send(event, context, cfnresponse.SUCCESS,responseData,"SubnetCheckInfo")
 else:
   responseData['Data'] = "Service Subnet1 is not attached to an Internet Gateway or NAT Gateway."
   cfnresponse.send(event, context, cfnresponse.FAILED,responseData,"SubnetCheckInfo")

def subnet_az_checker(subnetId, regionId):
 ec2 = boto3.resource('ec2', region_name=regionId)
 subnet = ec2.Subnet(subnetId)
 subnet_region=subnet.availability_zone
 return subnet_region