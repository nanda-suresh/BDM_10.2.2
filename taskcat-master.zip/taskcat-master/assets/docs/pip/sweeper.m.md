Module sweeper
--------------

Classes
-------
Sweeper 
    Ancestors (in MRO)
    ------------------
    sweeper.Sweeper
    builtins.object

    Static methods
    --------------
    __init__(self, session)
        Initialize self.  See help(type(self)) for accurate signature.

    delete_all(self, stack_list)

    Instance variables
    ------------------
    session
