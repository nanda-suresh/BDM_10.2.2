
class TaskCatException(Exception):
    """Raised when taskcat experiences a fatal error"""
    pass
